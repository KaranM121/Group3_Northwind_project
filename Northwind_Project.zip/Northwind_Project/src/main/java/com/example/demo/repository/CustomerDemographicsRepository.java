package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.CustomerDemographics;

public interface CustomerDemographicsRepository extends JpaRepository<CustomerDemographics, Integer> {

}
