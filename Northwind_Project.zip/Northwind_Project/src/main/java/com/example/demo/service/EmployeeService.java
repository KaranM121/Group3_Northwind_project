package com.example.demo.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.example.demo.dto.EmployeeAgeInfo;
import com.example.demo.dto.EmployeeTerritoryRegion;
import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.model.Employees;

public interface EmployeeService {

	Employees getEmployeeById(int employeeNumber) throws EmployeeNotFoundException;

	List<Employees> getAllEmployees();

	void createEmployee(Employees employee);

	Employees updateEmployee(Employees employee) throws EmployeeNotFoundException;

	void deleteEmployee(int employeeNumber) throws EmployeeNotFoundException;

	List<Employees> getEmployeeByfirstName(String firstName) throws EmployeeNotFoundException;
	
	List<Employees> findByfirstName(String firstName);
	
	List<Employees> getEmployeeByCity(String city);

	List<Employees> getEmployeeByTitle(String title);

	List<Employees> getEmployeeByBirthDate(Date birthDate);

	List<EmployeeAgeInfo> getEmployeeAgeInfoByBirthDate(Date birthDate);

	Map<String, String> getManagerNamesForEachEmployee();

	Map<String, Integer> getNumberOfEmployeesUnderEachManager();

	List<EmployeeTerritoryRegion> getEmployeeTerritoriesRegion();

	List<Employees> getEmployeeByAge(Date birthDate);

	List<EmployeeAgeInfo> getEmployeeInfoByAge(Date birthDate);
	

}