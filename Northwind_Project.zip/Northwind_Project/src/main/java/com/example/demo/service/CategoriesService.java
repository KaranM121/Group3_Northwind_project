package com.example.demo.service;

import java.util.List;

import com.example.demo.exception.CategoriesNotFoundException;
import com.example.demo.model.Categories;

public interface CategoriesService {

    Categories getCategoriesById(int categoryNumber) throws CategoriesNotFoundException;

    List<Categories> getAllCategories();

    void createCategories(Categories category);

    Categories updateCategories(Categories category) throws CategoriesNotFoundException;

    void deleteCategories(int categoryNumber) throws CategoriesNotFoundException;

	List<Categories> getCategoriesByName(String categoryname) throws CategoriesNotFoundException;
    
	
}
