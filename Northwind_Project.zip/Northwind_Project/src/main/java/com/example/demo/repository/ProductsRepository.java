

package com.example.demo.repository;

 

import java.util.List;

 

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;

 

import com.example.demo.model.Products;

 

public interface ProductsRepository extends JpaRepository<Products, Integer>{

 

	List<Products> findByQuantityPerUnit(int quantityPerUnit);

 

	List<Products> findByDiscounted(int discounted);

 

	List<Products> findByUnitPriceLessThan(double unitPrice);

 

	List<Products> getProductsBySupplierId(int supplierId);

 

	List<Products> findBySupplierId(int supplierId);

 

	List<Products> findByUnitsInStock(int unitsInStock);

 

	List<Products> findByUnitsOnOrderGreaterThan(int i);



	Products findFirstByOrderByUnitPriceDesc();


	@Query("SELECT p FROM Products p WHERE p.unitPrice > (SELECT MAX(p2.unitPrice) FROM Products p2)")

    List<Products> findProductsByUnitPriceGreaterThanAny();

 

	List<Products> findByCategoriesCategoryName(String categoryName);

 

}
