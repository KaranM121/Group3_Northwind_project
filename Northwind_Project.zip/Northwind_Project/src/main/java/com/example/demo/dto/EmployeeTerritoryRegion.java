package com.example.demo.dto;

public class EmployeeTerritoryRegion {
	
	    private String firstName;
	    private String territoryDescription;
	    private String regionDescription;
	    
	    
		public EmployeeTerritoryRegion(String firstName, String territoryDescription, String regionDescription) {
			super();
			this.firstName = firstName;
			this.territoryDescription = territoryDescription;
			this.regionDescription = regionDescription;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getTerritoryDescription() {
			return territoryDescription;
		}
		public void setTerritoryDescription(String territoryDescription) {
			this.territoryDescription = territoryDescription;
		}
		public String getRegionDescription() {
			return regionDescription;
		}
		public void setRegionDescription(String regionDescription) {
			this.regionDescription = regionDescription;
		}
	    
	    

}
