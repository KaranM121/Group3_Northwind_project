package com.example.demo.service;

 

 

import java.util.List;

 

import org.springframework.beans.factory.annotation.Autowired;

 

import org.springframework.stereotype.Service;

 

 

import com.example.demo.model.Shippers;

 

import com.example.demo.exception.ShippersNotFoundException;

 

import com.example.demo.repository.ShippersRepository;

 

 

@Service
public class ShippersServiceImpl implements ShippersService {

 


    @Autowired
    private ShippersRepository shippersRepository;

 

 

    @Override
    public Shippers getShipperById(int shipperId) throws ShippersNotFoundException {
        if (shippersRepository.findById(shipperId).isEmpty()) {
            throw new ShippersNotFoundException("The shipper with ID " + shipperId + " does not exist");
        }
        return shippersRepository.findById(shipperId).get();
    }

 

    
    @Override
    public List<Shippers> getAllShippers() {
        return shippersRepository.findAll();
    }

 

 

    @Override
    public void createShipper(Shippers shipper) {
        shippersRepository.save(shipper);
    }

 

 

    @Override
    public Shippers updateShipper(Shippers shipper) throws ShippersNotFoundException {
        if (shippersRepository.findById(shipper.getShipperID()).isEmpty()) {
            throw new ShippersNotFoundException("The shipper with ID " + shipper.getShipperID() + " does not exist");
        }
        return shippersRepository.save(shipper);
    }

 

 

    @Override
    public void deleteShipper(int shipperId) throws ShippersNotFoundException {
        if (shippersRepository.findById(shipperId).isEmpty()) {
            throw new ShippersNotFoundException("The shipper with ID " + shipperId + " does not exist");
        }
        shippersRepository.deleteById(shipperId);
    }

 

 

	@Override
	public List<Shippers> findAllByOrderByCompanyName() {
		// TODO Auto-generated method stub
		return null;
	}

 

 

	

 

 

  //********************  

	public Shippers updateShipperById(Shippers shippers) throws ShippersNotFoundException {
	    // Check if the department with the specified department number exists.
	    if (shippersRepository.findById(shippers.getShipperID()).isEmpty()) {
	        throw new ShippersNotFoundException("The department with " + shippers.getShipperID() + " doesn't exist");
	    }
	    // If the department exists, update it using the repository.
	    return shippersRepository.save(shippers);
	}

 

 

	@Override
	public List<Shippers> getShippersByCompanyName(String companyName) throws ShippersNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

 

 

	

 

}