package com.example.demo.exception;

public class SuppliersNotFoundException extends Exception {

	String message;

	public SuppliersNotFoundException(String message) {
		this.message = message;

	}

	public String getMessage() {
		return message;

	}

}