package com.example.demo.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.dto.EmployeeAgeInfo;
import com.example.demo.model.Employees;

public interface EmployeesRepository extends JpaRepository<com.example.demo.model.Employees, Integer>{
	
	 @Query("SELECT e FROM Employees e WHERE e.firstName =?1")
	 
	 List<Employees> findByfirstName(@Param("firstName") String firstName);
	 
	 
	 @Query("SELECT e FROM Employees e WHERE e.city = ?1")
	 
	 List<Employees> findEmployeesByCity(@Param("city") String city);

	 
	 List<Employees> getEmployeeByTitle(@Param("title") String title);
     
     @Query("SELECT e FROM Employees e WHERE e.birthDate =?1")
     
     
     List<Employees> findEmployeesByBirthDate(@Param("birthDate") Date birthDate);
     
     @Query("SELECT new com.example.demo.dto.EmployeeAgeInfo(e.firstName, e.lastName, e.birthDate) FROM Employees e WHERE e.birthDate = ?1")
     
     List<EmployeeAgeInfo> findEmployeeAgeInfoByBirthDate(@Param("birthDate") Date birthDate);
	

}
