package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.EmployeeAgeInfo;
import com.example.demo.dto.EmployeeTerritoryRegion;
import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.model.Employees;
import com.example.demo.service.EmployeeService;

import java.util.Collection;
import java.util.Date;


import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/employee")
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;

    // POST endpoint to create a new employee
    @PostMapping("/add")
    public ResponseEntity<String> createEmployee(@RequestBody Employees employee) {
        employeeService.createEmployee(employee);
        return new ResponseEntity<>("Record Created Successfully", HttpStatus.CREATED);
    }

    // GET endpoint to display all employees
    @GetMapping("/getAll")
    public ResponseEntity<List<Employees>> getAllEmployees() {
    	List<Employees> employee = employeeService.getAllEmployees();
        return ResponseEntity.ok(employee);
    }

    // GET endpoint to get an employee by ID
    @GetMapping("/{employeeNumber}")
    public ResponseEntity<Employees> getEmployeeById(@PathVariable int employeeNumber) {
        try {
            Employees employee = employeeService.getEmployeeById(employeeNumber);
            return ResponseEntity.ok(employee);
        } catch (EmployeeNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // PUT endpoint to update an employee
    @PutMapping("/{employeeNumber}")
    public ResponseEntity<Employees> updateEmployee(@PathVariable int employeeNumber, @RequestBody Employees updatedEmployee) {
        try {
            updatedEmployee.setId(employeeNumber);
            Employees employee = employeeService.updateEmployee(updatedEmployee);
            return ResponseEntity.ok(employee);
        } catch (EmployeeNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // DELETE endpoint to delete an employee by ID
    @DeleteMapping("/{employeeNumber}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable int employeeNumber) {
        try {
            employeeService.deleteEmployee(employeeNumber);
            return ResponseEntity.noContent().build();
        } catch (EmployeeNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    // GET endpoint to search employees by first name
    @GetMapping("/firstname/{firstname}")
    public List<Employees> getEmployeesByFirstName(@PathVariable String firstname) throws EmployeeNotFoundException {
        return employeeService.getEmployeeByfirstName(firstname);
    }

    @GetMapping("/title/{title}")
    public List<Employees> getEmployeesByTitle(@PathVariable String title) {
        return employeeService.getEmployeeByTitle(title);
    }


    // GET endpoint to search employees by birth date
    @GetMapping("/birthdate/{birthDate}")
    public List<Employees> getEmployeesByBirthDate(@PathVariable Date birthDate) {
        return employeeService.getEmployeeByBirthDate(birthDate);
    }

    // GET endpoint to search employees by city
    @GetMapping("/city/{city}")
    public List<Employees> getEmployeesByCity(@PathVariable String city) {
        return employeeService.getEmployeeByCity(city);
    }

    // GET endpoint to display first name, last name, and age of all employees
    @GetMapping("/age/{birthDate}")
    public List<EmployeeAgeInfo> getEmployeeByAge(@PathVariable Date birthDate) {
        return employeeService.getEmployeeAgeInfoByBirthDate(birthDate);
    }

    // GET endpoint to display the number of employees under each manager
    @GetMapping("/numberofemployeeundereachmanager")
    public Map<String, Integer> getNumberOfEmployeesUnderEachManager() {
        return employeeService.getNumberOfEmployeesUnderEachManager();
    }

    // GET endpoint to display manager names for each employee
    @GetMapping("/managerandemployeename")
    public Map<String, String> getManagerNamesForEachEmployee() {
        return employeeService.getManagerNamesForEachEmployee();
    }

    // GET endpoint to display first name, territory description, and region description for each employee
    @GetMapping("/employeeterritoriesregion")
    public List<EmployeeTerritoryRegion> getEmployeeTerritoriesRegion() {
        return employeeService.getEmployeeTerritoriesRegion();
    }

}
