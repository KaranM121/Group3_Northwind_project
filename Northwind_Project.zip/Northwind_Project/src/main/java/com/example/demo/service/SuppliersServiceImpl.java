package com.example.demo.service;

import java.util.List;
import java.util.function.Supplier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employees;
import com.example.demo.model.Suppliers;
import com.example.demo.model.Suppliers;
import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.exception.SuppliersNotFoundException;
import com.example.demo.repository.SuppliersRepository;

@Service
public class SuppliersServiceImpl implements SuppliersService {

	@Autowired
	SuppliersRepository SuppliersRepository;
	
	@Override
    public Suppliers getSuppliersById(int SuppliersNumber) throws SuppliersNotFoundException {
        return SuppliersRepository.findById(SuppliersNumber)
            .orElseThrow(() -> new SuppliersNotFoundException("The Suppliers with ID " + SuppliersNumber + " does not exist"));
    }

    @Override
    public List<Suppliers> getAllSuppliers() {
        return SuppliersRepository.findAll();
    }

    @Override
    public void createSuppliers(Suppliers Suppliers) {
        SuppliersRepository.save(Suppliers);
    }

    @Override
    public Suppliers updateSupplier(Suppliers suppliers) throws SuppliersNotFoundException {
        int suppliersId = suppliers.getSupplierID();
        if (!SuppliersRepository.existsById(suppliersId)) {
            throw new SuppliersNotFoundException("The suppliers with ID " + suppliersId + " does not exist");
        }
        return SuppliersRepository.save(suppliers);
    }

    @Override
    public void deleteSuppliers(int SuppliersNumber) throws SuppliersNotFoundException {
        if (!SuppliersRepository.existsById(SuppliersNumber)) {
            throw new SuppliersNotFoundException("The Suppliers with ID " + SuppliersNumber + " does not exist");
        }
        SuppliersRepository.deleteById(SuppliersNumber);
    }

    @Override
    public List<Suppliers> getSuppliersByCountry(String country) {
        return SuppliersRepository.findByCountry(country);
    }

    @Override
    public List<Suppliers> getSuppliersByRegionNotNull() {
        return SuppliersRepository.findByRegionNotNull();
    }

    @Override
    public List<Suppliers> getSuppliersByContactTitleContaining(String title) {
        return SuppliersRepository.findByContactTitleContaining(title);
    }

    @Override
    public List<Object[]> getNumberOfSuppliersByCountry() {
        return SuppliersRepository.findNumberOfSuppliersByCountry();
    }

	@Override
	public Suppliers getSuppliersById(String country) throws SuppliersNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void createSuppliers(Supplier supplier) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Suppliers updateSuppliers(Suppliers Suppliers) throws SuppliersNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employees updateEmployee(Employees employee) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}
}

