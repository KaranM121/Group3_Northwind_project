package com.test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.server.ResponseStatusException;

import com.example.demo.controller.CustomersController;
import com.example.demo.exception.CustomerNotFoundException;
import com.example.demo.model.Customers;
import com.example.demo.service.CustomersService;

import java.util.ArrayList;
import java.util.List;

class CustomersControllerTest {

    private CustomersController customersController;

    private CustomersService customersService;

    @BeforeEach
    void setUp() {
        customersService = mock(CustomersService.class);
        customersController = new CustomersController(customersService);
    }

    @Test
    void testAddCustomer() {
        Customers customer = new Customers(); // Create a sample customer

        // Mock the behavior of the service when adding a customer
        doNothing().when(customersService).addCustomer(customer);

        ResponseEntity<String> response = customersController.addCustomer(customer);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Record Created Successfully", response.getBody());
    }

    @Test
    void testGetAllCustomers() {
        List<Customers> customersList = new ArrayList<>(); // Create a sample list of customers

        // Mock the behavior of the service when getting all customers
        when(customersService.getAllCustomers()).thenReturn(customersList);

        ResponseEntity<List<Customers>> response = customersController.getAllCustomers();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(customersList, response.getBody());
    }

    @Test
    void testUpdateContactNameOfCustomer() throws CustomerNotFoundException {
        int customerId = 1;
        String newContactName = "New Contact Name";

        Customers existingCustomer = new Customers();
        existingCustomer.setCustomerId(customerId);

        // Mock the behavior of the service when updating the contact name of a customer
        when(customersService.getCustomerById(customerId)).thenReturn(existingCustomer);
        doNothing().when(customersService).saveCustomer(existingCustomer);

        assertDoesNotThrow(() -> customersController.updateContactNameOfCustomer(customerId, newContactName));
        assertEquals(newContactName, existingCustomer.getContactName());
    }

    @Test
    void testUpdateContactNameOfCustomer_NotFound() throws CustomerNotFoundException {
        int customerId = 1;
        String newContactName = "New Contact Name";

        // Mock the behavior of the service when updating the contact name of a customer
        when(customersService.getCustomerById(customerId)).thenReturn(null);

        assertThrows(ResponseStatusException.class, () -> customersController.updateContactNameOfCustomer(customerId, newContactName));
    }

    // Add more test methods for other controller endpoints as needed...
}
