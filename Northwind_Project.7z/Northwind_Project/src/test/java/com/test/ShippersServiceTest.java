package com.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.exception.ShippersNotFoundException;
import com.example.demo.model.Shippers;
import com.example.demo.repository.ShippersRepository;
import com.example.demo.service.ShippersServiceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

class ShippersServiceImplTest {

    @InjectMocks
    private ShippersServiceImpl shippersService;

    @Mock
    private ShippersRepository shippersRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetShipperById() throws ShippersNotFoundException {
        int shipperId = 1;
        Shippers expectedShipper = new Shippers();
        expectedShipper.setShipperID(shipperId);
        when(shippersRepository.findById(shipperId)).thenReturn(Optional.of(expectedShipper));

        Shippers result = shippersService.getShipperById(shipperId);

        assertEquals(expectedShipper, result);
    }

    @Test
    void testGetShipperById_ShouldThrowNotFoundException() {
        int shipperId = 1;
        when(shippersRepository.findById(shipperId)).thenReturn(Optional.empty());

        assertThrows(ShippersNotFoundException.class, () -> shippersService.getShipperById(shipperId));
    }

    @Test
    void testGetAllShippers() {
        List<Shippers> expectedShippers = new ArrayList<>();
        when(shippersRepository.findAll()).thenReturn(expectedShippers);

        List<Shippers> result = shippersService.getAllShippers();

        assertEquals(expectedShippers, result);
    }

    @Test
    void testCreateShipper() {
        Shippers shipper = new Shippers();
        shippersService.createShipper(shipper);

        verify(shippersRepository, times(1)).save(shipper);
    }

    @Test
    void testUpdateShipper() throws ShippersNotFoundException {
        Shippers shipper = new Shippers();
        shipper.setShipperID(1);
        when(shippersRepository.findById(shipper.getShipperID())).thenReturn(Optional.of(shipper));

        Shippers updatedShipper = shippersService.updateShipper(shipper);

        assertEquals(shipper, updatedShipper);
        verify(shippersRepository, times(1)).save(shipper);
    }

    @Test
    void testUpdateShipper_ShouldThrowNotFoundException() {
        Shippers shipper = new Shippers();
        shipper.setShipperID(1);
        when(shippersRepository.findById(shipper.getShipperID())).thenReturn(Optional.empty());

        assertThrows(ShippersNotFoundException.class, () -> shippersService.updateShipper(shipper));
    }

    @Test
    void testDeleteShipper() throws ShippersNotFoundException {
        int shipperId = 1;
        when(shippersRepository.findById(shipperId)).thenReturn(Optional.of(new Shippers()));

        shippersService.deleteShipper(shipperId);

        verify(shippersRepository, times(1)).deleteById(shipperId);
    }

    @Test
    void testDeleteShipper_ShouldThrowNotFoundException() {
        int shipperId = 1;
        when(shippersRepository.findById(shipperId)).thenReturn(Optional.empty());

        assertThrows(ShippersNotFoundException.class, () -> shippersService.deleteShipper(shipperId));
    }

}
