package com.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ShippersControllerTest {

	@Test
	void testAddShipper() {
		fail("Not yet implemented");
	}

	@Test
	void testGetAllShippers() {
		fail("Not yet implemented");
	}

	@Test
	void testUpdateShipperDetails() {
		fail("Not yet implemented");
	}

	@Test
	void testSearchShipperByCompanyName() {
		fail("Not yet implemented");
	}

	@Test
	void testEditShipperDetails() {
		fail("Not yet implemented");
	}

}
