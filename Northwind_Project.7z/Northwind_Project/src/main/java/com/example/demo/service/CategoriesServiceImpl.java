package com.example.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Categories;
import com.example.demo.exception.CategoriesNotFoundException;
import com.example.demo.repository.CategoriesRepository;
@Service
public class CategoriesServiceImpl implements CategoriesService {

    @Autowired
    private CategoriesRepository categoriesRepository;

    @Override
    public Categories getCategoriesById(int categoryId) throws CategoriesNotFoundException {
        if (categoriesRepository.findById(categoryId).isEmpty()) {
            throw new CategoriesNotFoundException("The category with ID " + categoryId + " does not exist");
        }
        return categoriesRepository.findById(categoryId).get();
    }

    @Override
    public List<Categories> getAllCategories() {
        return categoriesRepository.findAll();
    }

    @Override
    public void createCategories(Categories category) {
        categoriesRepository.save(category);
    }

    @Override
    public Categories updateCategories(Categories category) throws CategoriesNotFoundException {
        int categoryId = category.getCategoryId();
        if (categoriesRepository.findById(categoryId).isEmpty()) {
            throw new CategoriesNotFoundException("The category with ID " + categoryId + " does not exist");
        }
        return categoriesRepository.save(category);
    }

    @Override
    public void deleteCategories(int categoryId) throws CategoriesNotFoundException {
        if (categoriesRepository.findById(categoryId).isEmpty()) {
            throw new CategoriesNotFoundException("The category with ID " + categoryId + " does not exist");
        }
        categoriesRepository.deleteById(categoryId);
    }

    @Override
    public List<Categories> getCategoriesByName(String categoryName) throws CategoriesNotFoundException {
		
		  List<Categories> category = categoriesRepository.findByCategoryName(categoryName);
		  
		  if (category == null) { throw new
		  CategoriesNotFoundException("Category with name " + categoryName +
		  " not found"); }
		 
        
        return categoriesRepository.findByCategoryName(categoryName);
    }
}
