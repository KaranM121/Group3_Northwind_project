package com.example.demo.uicontroller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.example.demo.exception.ShippersNotFoundException;
import com.example.demo.model.Shippers;
import com.example.demo.model.Suppliers;
import com.example.demo.repository.SuppliersRepository;
import com.example.demo.service.ShippersService;

@Controller
@RequestMapping("/api/ui/shippers")
public class ShippersUIController {
	
	@Autowired
    ShippersService shippersService;
	
	@RequestMapping(method = RequestMethod.GET , value="/all")
	public String getAllShippers(Model model) {
		List<Shippers> shippers=shippersService.getAllShippers();
		model.addAttribute("shippers", shippers);
		return "allShippers";
	}
	
	@RequestMapping(method = RequestMethod.GET , value="/delete/{id}")
	public String getShippersAddForm(@PathVariable("id") int id) throws ShippersNotFoundException  {
		System.out.println(id);
		shippersService.deleteShipper(id);
		return "redirect:/api/ui/shippers/all";
	}
	
	@RequestMapping(method = RequestMethod.GET , value="/add")
	public String getShippersAddForm(Model model) {
		Shippers shipper = new Shippers();
		shipper.setShipperID(12343);
		model.addAttribute("shipper", shipper);
		return "addShippers";
	}
	
	
	@RequestMapping(method = RequestMethod.POST , value="/add")
	public String addNewShippers(@ModelAttribute("shipper")  Shippers  shippers) {
		
		shippersService.createShipper(shippers);
		return "redirect:/api/ui/shippers/all";
	}
	
	
	
	@RequestMapping(method = RequestMethod.GET , value="/view/{id}")
	public String getShippersById(Model model , @PathVariable("id") int id) throws ShippersNotFoundException   {
		Shippers shippers=shippersService.getShipperById(id);
		model.addAttribute("shipper", shippers);
		return "oneShippers";
	}
	
	//edit
	@GetMapping("/edit/{id}")
	public String getShipperEditForm(Model model, @PathVariable("id") int id) throws ShippersNotFoundException {
	    Shippers shipper = shippersService.getShipperById(id);
	    model.addAttribute("shipper", shipper);
	    return "editShippers";
	}
	@PostMapping("/edit/{id}")
	public String updateShipper(@ModelAttribute("shipper") Shippers shipper,Model model) throws ShippersNotFoundException {
	    shippersService.updateShipper(shipper);
	    return "redirect:/api/ui/shippers/all"; // Redirect to the list of all shippers
	}

	

}
