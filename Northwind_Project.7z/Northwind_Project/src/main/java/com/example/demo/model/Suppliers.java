package com.example.demo.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="SUPPLIERS")

public class Suppliers {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="SUPPLIER_ID")
	private int SupplierID;
	
	@Column(name="COMPANY_NAME")
	private String CompanyName;
	
	@Column(name="CONTACT_NAME")
	private String ContactName;
	
	@Column(name="CONTACT_TITLE")
	private String ContactTitle;
	
	@Column(name="COURSE_NAME")
	private String CourseName;
	
	@Column(name="ADDRESS")
	private String Address;
	
	@Column(name="CITY")
	private String City;
	
	@Column(name="REGION")
	private String Region;
	
	@Column(name="POSTAL_CODE")
	private String PostalCode;
	
	@Column(name="COUNTRY")
	private String Country;
	
	@Column(name="PHONE")
	private String Phone;
	
	@Column(name="FAX")
	private String Fax;
	
	@Column(name="HOME_PAGE")
	private String HomePage;
	
	
	@OneToMany(mappedBy = "suppliers", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Products> products;

	

	public int getSupplierID() {
		return SupplierID;
	}

	public void setSupplierID(int supplierID) {
		this.SupplierID = supplierID;
	}

	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyName) {
		this.CompanyName = companyName;
	}

	public String getContactName() {
		return ContactName;
	}

	public void setContactName(String contactName) {
		this.ContactName = contactName;
	}

	public String getContactTitle() {
		return ContactTitle;
	}

	public void setContactTitle(String contactTitle) {
		this.ContactTitle = contactTitle;
	}

	public String getCourseName() {
		return CourseName;
	}

	public void setCourseName(String courseName) {
		this.CourseName = courseName;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		this.Address = address;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		this.City = city;
	}

	public String getRegion() {
		return Region;
	}

	public void setRegion(String region) {
		this.Region = region;
	}

	public String getPostalCode() {
		return PostalCode;
	}

	public void setPostalCode(String postalCode) {
		this.PostalCode = postalCode;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		this.Country = country;
	}

	public String getPhone() {
		return Phone;
	}

	public void setPhone(String phone) {
		this.Phone = phone;
	}

	public String getFax() {
		return Fax;
	}

	public void setFax(String fax) {
		this.Fax = fax;
	}

	public String getHomePage() {
		return HomePage;
	}

	public void setHomePage(String homePage) {
		this.HomePage = homePage;
	}
	
}
