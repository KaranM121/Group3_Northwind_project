package com.example.demo.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="ORDERS")

public class Orders {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ORDER_ID")
	private int orderID;
	

	@Column(name="C_ID")
	private int customerID;

	public Customers getCustomers() {
		return customers;
	}

	public void setCustomers(Customers customers) {
		this.customers = customers;
	}

	@Column(name="EMPLOYEE_ID", insertable = false, updatable = false)
	private int employeeID;

	
	@Column(name="ORDER_DATE")
	private int orderDate;
	
	@Column(name="REQUIRED_DATE")
	private int requiredDate;
	
	@Column(name="SHIPPED_DATE")
	private String shippedDate;
	
	@Column(name="SHIP_VIA")
	private String shipVia;
	
	@Column(name="FREIGHT")
	private String freight;
	
	@Column(name="SHIP_NAME")
	private String shipName;
	
	@Column(name="SHIP_ADDRESS")
	private String shipAddress;
	
	@Column(name="SHIP_CITY")
	private String shipCity;
	
	@Column(name="SHIP_REGION")
	private String shipRegion;
	
	@Column(name="SHIP_POSTALCODE")
	private String shipPostalCode;
	
	@Column(name="SHIP_COUNTRY")
	private String shipCountry;
	
	
	public List<OrderDetails> getOrderdetails() {
		return orderdetails;
	}

	public void setOrderdetails(List<OrderDetails> orderdetails) {
		this.orderdetails = orderdetails;
	}

	public Shippers getShippers() {
		return shippers;
	}

	public void setShippers(Shippers shippers) {
		this.shippers = shippers;
	}

	public Employees getEmployees() {
		return employees;
	}

	public void setEmployees(Employees employees) {
		this.employees = employees;
	}

	@OneToMany(mappedBy = "order", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<OrderDetails> orderdetails;
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "SHIPPER_ID")
    private Shippers shippers;
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "EMPLOYEE_ID")
    private Employees employees;
	
	@ManyToOne
    @JoinColumn(name = "CUSTOMER_ID")
    private Customers customers;
	
	

	public int getOrderID() {
		return orderID;
	}

	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}

	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public int getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}

	public int getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(int orderDate) {
		this.orderDate = orderDate;
	}

	public int getRequiredDate() {
		return requiredDate;
	}

	public void setRequiredDate(int requiredDate) {
		this.requiredDate = requiredDate;
	}

	public String getShippedDate() {
		return shippedDate;
	}

	public void setShippedDate(String shippedDate) {
		this.shippedDate = shippedDate;
	}

	public String getShipVia() {
		return shipVia;
	}

	public void setShipVia(String shipVia) {
		this.shipVia = shipVia;
	}

	public String getFreight() {
		return freight;
	}

	public void setFreight(String freight) {
		this.freight = freight;
	}

	public String getShipName() {
		return shipName;
	}

	public void setShipName(String shipName) {
		this.shipName = shipName;
	}

	public String getShipAddress() {
		return shipAddress;
	}

	public void setShipAddress(String shipAddress) {
		this.shipAddress = shipAddress;
	}

	public String getShipCity() {
		return shipCity;
	}

	public void setShipCity(String shipCity) {
		this.shipCity = shipCity;
	}

	public String getShipRegion() {
		return shipRegion;
	}

	public void setShipRegion(String shipRegion) {
		this.shipRegion = shipRegion;
	}

	public String getShipPostalCode() {
		return shipPostalCode;
	}

	public void setShipPostalCode(String shipPostalCode) {
		this.shipPostalCode = shipPostalCode;
	}

	public String getShipCountry() {
		return shipCountry;
	}

	public void setShipCountry(String shipCountry) {
		this.shipCountry = shipCountry;
	}

	public Orders() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
