package com.example.demo.exception;

public class TerritoriesNotFoundException extends Exception{
	String message;

	public TerritoriesNotFoundException(String message) {
		this.message = message;

	}

	public String getMessage() {
		return message;

	}
}



