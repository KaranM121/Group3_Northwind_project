package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.model.Customers;

public interface CustomerRepository extends JpaRepository<Customers , Integer> {
	
	@Query("SELECT c FROM Customers c WHERE c.companyName = :companyName")
	List<Customers> searchCustomersByCompanyName(@Param("companyName") String companyName);
	
	@Query("SELECT c FROM Customers c WHERE c.contactTitle = :contactTitle")
	List<Customers> searchCustomersByContactTitle(@Param("contactTitle") String contactTitle);
	
	@Query("SELECT c FROM Customers c WHERE c.country = :country")
	List<Customers> searchCustomersByCountry(@Param("country") String country);
	
	@Query("SELECT c FROM Customers c WHERE c.city = :city")
	List<Customers> searchCustomersByCity(@Param("city") String city);
	
	@Query("SELECT c FROM Customers c WHERE c.region = :region")
	List<Customers> searchCustomersByRegion(@Param("region") String region);
	
	@Query("SELECT c FROM Customers c WHERE c.fax = :fax")
	Customers searchCustomerByFax(@Param("fax") String fax);
	
	@Query("SELECT c FROM Customers c WHERE c.region IS NOT NULL")
	List<Customers> searchCustomersWithRegionNotNull();
	
	@Query("SELECT DISTINCT c FROM Customers c WHERE c.contactTitle = :contactTitle")
	List<Customers> searchCustomersByUniqueContactTitle(@Param("contactTitle") String contactTitle);
	
	//Custom query (GET)
	@Query(value = "SELECT country, COUNT(*) FROM Customers GROUP BY country", nativeQuery = true)
	List<Object[]> getNumberOfCustomersByCountry();


}