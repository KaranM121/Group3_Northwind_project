package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.example.demo.exception.RegionNotFoundException;
import com.example.demo.model.Region;
import com.example.demo.service.RegionService;

import java.util.List;

@Controller
@RequestMapping("/api/region")
public class RegionController {
    @Autowired
    private RegionService regionService;

    // POST endpoint to add a new Territory
    @PostMapping("/add")
    public ResponseEntity<String> addRegion(@RequestBody Region region) {
        regionService.createRegion(region);
        return ResponseEntity.status(HttpStatus.CREATED).body("Record Created Successfully");
    }

    // GET endpoint to display all Territories
    @GetMapping("/getAll")
    public List<Region> getAllRegions() {
        return regionService.getAllRegions();
    }

    // PUT endpoint to update a Territory by RegionId
    @PutMapping("put/{regionId}")
    public ResponseEntity<Void> updateRegion(@PathVariable int regionId, @RequestBody Region updatedRegion) {
        try {
            updatedRegion.setRegionId(regionId);
            regionService.updateRegion(updatedRegion);
            return ResponseEntity.noContent().build();
        } catch (RegionNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // GET endpoint to search for a Territory by RegionId
    @GetMapping("/{regionId}")
    public ResponseEntity<Region> getRegionById(@PathVariable int regionId) {
        try {
            Region region = regionService.getRegionById(regionId);
            return ResponseEntity.ok(region);
        } catch (RegionNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // DELETE endpoint to delete a Territory by RegionId
    @DeleteMapping("/{regionId}")
    public ResponseEntity<Void> deleteRegion(@PathVariable int regionId) {
        try {
            regionService.deleteRegion(regionId);
            return ResponseEntity.noContent().build();
        } catch (RegionNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
