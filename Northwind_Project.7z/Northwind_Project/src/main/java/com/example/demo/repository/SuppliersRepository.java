package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.model.Suppliers;

public interface SuppliersRepository extends JpaRepository<Suppliers, Integer> {
    @Query("select s from Suppliers s where s.Country =?1")
	List<Suppliers> findByCountry(String country);
	
	 @Query("SELECT s FROM Suppliers s WHERE s.Region IS NOT NULL")
    List<Suppliers> findByRegionNotNull();
    
    @Query("select s from Suppliers s where s.ContactTitle = ?1")
    List<Suppliers> findByContactTitleContaining(String title);

    @Query("SELECT s.Country, COUNT(s) FROM Suppliers s GROUP BY s.Country")
    List<Object[]> findNumberOfSuppliersByCountry();

	static List<Suppliers> findAllByOrderByCompanyName() {
		// TODO Auto-generated method stub
		return null;
	}
}
