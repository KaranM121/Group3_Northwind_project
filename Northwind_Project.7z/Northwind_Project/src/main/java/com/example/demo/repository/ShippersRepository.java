package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.model.Shippers;

public interface ShippersRepository extends JpaRepository<Shippers, Integer>{
	
	@Query("SELECT s FROM Shippers s WHERE s.companyName = :companyName")
    List<Shippers> getShippersByCompanyName(@Param("companyName") String companyName);
	
	@Query("SELECT s FROM Shippers s")
	List<Shippers> getAllShippers();

}