

package com.example.demo.controller;

import java.util.List;

import java.util.Map;

 

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Products;

import com.example.demo.service.ProductsService;

import com.example.demo.exception.ProductsNotFoundException;

 

@RestController

@RequestMapping("/api/products")

public class ProductsController {

	 @Autowired

	    private ProductsService productsService;

 

//working

	    @PostMapping("/add")

	    public ResponseEntity<String> addProduct(@RequestBody Products product) {

	        productsService.createProducts(product);

	        return ResponseEntity.status(HttpStatus.CREATED).body("Record Added Successfully!!");

	    }

 

	    @ExceptionHandler(ProductsNotFoundException.class)

	    public ResponseEntity<String> handleProductsNotFoundException(ProductsNotFoundException ex) {

	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());

	    }


//working    

	    @GetMapping("/get")

	    public ResponseEntity<List<Products>> getAllProducts() {

	        List<Products> products = productsService.getAllProducts();

	        return ResponseEntity.ok(products);

	    }

 

//working	   

	    @PutMapping("/edit1/{productId}")

	    public ResponseEntity<Void> updateProduct(@PathVariable int productId, @RequestBody Products product) {

	        try {

	            Products updatedProduct = productsService.updateProducts(product);

	            if (updatedProduct != null) {

	                return ResponseEntity.noContent().build();

	            } else {

	                return ResponseEntity.notFound().build();

	            }

	        } catch (ProductsNotFoundException e) {

	            return ResponseEntity.notFound().build();

	        }

	    }

//working	    

	    @PatchMapping("/edit/{productId}")

	    public ResponseEntity<Void> partialUpdateProduct(@PathVariable int productId, @RequestBody Products product) {

	        try {

	            Products existingProduct = productsService.getProductsById(productId);

	            if (existingProduct != null) {

	                // Update specific fields of the product based on the PATCH request

	                if (product.getProductName() != null) {

	                    existingProduct.setProductName(product.getProductName());

	                }

	                if (product.getUnitPrice() != 0.0) {

	                    existingProduct.setUnitPrice(product.getUnitPrice());

	                }

	                // Add more fields as needed

 

	                productsService.updateProducts(existingProduct);

	                return ResponseEntity.noContent().build();

	            } else {

	                return ResponseEntity.notFound().build();

	            }

	        } catch (ProductsNotFoundException e) {

	            return ResponseEntity.notFound().build();

	        }

 

	    }

//working	    

	    @GetMapping("/quantityPerUnit/{quantityPerUnit}")

	    public ResponseEntity<List<Products>> searchQuantityPerUnit(@PathVariable int quantityPerUnit) {

	        List<Products> products = productsService.getQuantityPerUnit(quantityPerUnit);

	        return ResponseEntity.ok(products);

	    }
//WORKING BUT 

	    //We need to change the defination of discontinued products in the "Products" table

	    //in northwind database its "bit" datatype and we have take it as "int"


	    @GetMapping("/DiscontinuedProduct")

	    public ResponseEntity<List<Products>> getDiscontinuedProducts() {

	        List<Products> discontinuedProducts = productsService.getDiscontinuedProducts();

	        return ResponseEntity.ok(discontinuedProducts);

	    }
//working


	    @GetMapping("/unitPriceLessThan/{unitPrice}")

	    public ResponseEntity<List<Products>> getProductsByUnitPriceLessThan(@PathVariable double unitPrice) {

	        List<Products> products = productsService.getProductsByUnitPriceLessThan(unitPrice);

	        return ResponseEntity.ok(products);

	    }
//remaining	    


	    @GetMapping("/ByCategoryName/{CategoryName}")

	    public ResponseEntity<List<Products>> getProductsByCategoryName(@PathVariable String CategoryName) {

	        List<Products> products = productsService.getProductsByCategoryName(CategoryName);

	        return ResponseEntity.ok(products);

	    }
//remaining

	    @GetMapping("/ProductDetails")

	    public ResponseEntity<List<Map<String, String>>> getProductDetails() {

	        List<Map<String, String>> productDetails = productsService.getProductDetails();

	        return ResponseEntity.ok(productDetails);

	    }

//working


	    @GetMapping("/ProductDetails/SupplierID/{supplierId}")

	    public ResponseEntity<List<Products>> getProductsBySupplierIda(@PathVariable int supplierId) {

	        List<Products> products = productsService.getProductsBySupplierIda(supplierId);

	        return ResponseEntity.ok(products);

	    }

 

	    


//remaining	

 

	    @GetMapping("/CompanyName")

	    public ResponseEntity<List<String>> getSuppliersByProductCount(@RequestParam int productCount) {

	        List<String> companyNames = productsService.getSuppliersByProductCount(productCount);

	        return ResponseEntity.ok(companyNames);

	    }





//working


	    @GetMapping("/ProductBySupplier/{supplierId}")

	    public ResponseEntity<List<Products>> getProductsBySupplierId(@PathVariable int supplierId) {

	        List<Products> products = productsService.getProductsBySupplierId(supplierId);

	        return ResponseEntity.ok(products);

	    }

 

	   

//working

	    @PutMapping("/Edit/ProductID/{productId}")

	    public ResponseEntity<Void> updateUnitPrice(@PathVariable int productId, @RequestBody Map<String, Double> requestBody) {

	        try {

	            Products existingProduct = productsService.getProductsById(productId);

	            if (existingProduct != null) {

	                Double unitPrice = requestBody.get("unitPrice");

	                if (unitPrice != null) {

	                    existingProduct.setUnitPrice(unitPrice);

	                    productsService.updateProducts(existingProduct);

	                    return ResponseEntity.noContent().build();

	                } else {

	                    return ResponseEntity.badRequest().build(); 

	                }

	            } else {

	                return ResponseEntity.notFound().build();

	            }

	        } catch (ProductsNotFoundException e) {

	            return ResponseEntity.notFound().build();

	        }

	    }


//working


	    @GetMapping("/UnitInStock/{unitsInStock}")

	    public ResponseEntity<List<Products>> getProductsByUnitInStock(@PathVariable int unitsInStock) {

	        List<Products> products = productsService.getProductsByUnitInStock(unitsInStock);

	        if (products.isEmpty()) {

	            return ResponseEntity.notFound().build(); // Return 404 Not Found if no products are found

	        } else {

	            return ResponseEntity.ok(products);

	        }

	    }

 

//working

 

	    @GetMapping("/UnitsOnOrder")

	    public ResponseEntity<List<Products>> getProductsUnitsOnOrderGreaterThanZero() {

	        List<Products> products = productsService.getProductsUnitsOnOrderGreaterThanZero();

	        return ResponseEntity.ok(products);

	    }

 

//not_working

	    @GetMapping("/OutOfStock")

	    public ResponseEntity<List<Object[]>> getOutOfStockProducts() {

	        List<Object[]> outOfStockProducts = productsService.getOutOfStockProducts();

	        return ResponseEntity.ok(outOfStockProducts);

	    }

 

//working   

	    @GetMapping("/ProductByMaxPrice")

	    public ResponseEntity<Products> getProductWithMaxPrice() {

	        Products product = productsService.getProductWithMaxPrice();

	        if (product != null) {

	            return ResponseEntity.ok(product);

	        } else {

	            return ResponseEntity.notFound().build();

	        }

	    }

 

	    

//givingEmptyList	    

	    @GetMapping("/ProductByUnitPrice")

	    public ResponseEntity<List<Products>> getProductByUnitPrice() {

	        List<Products> products = productsService.getProductsByUnitPriceGreaterThanAny();

	        return ResponseEntity.ok(products);

	    }


}
