package com.example.demo.exception;

public class RegionNotFoundException extends Exception {

	String message;

	public RegionNotFoundException(String message) {
		this.message = message;

	}

	public String getMessage() {
		return message;

	}

}