package com.example.demo.exception;

public class CategoriesNotFoundException extends Exception {

    private String message;

    public CategoriesNotFoundException(String message) {
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }
}
