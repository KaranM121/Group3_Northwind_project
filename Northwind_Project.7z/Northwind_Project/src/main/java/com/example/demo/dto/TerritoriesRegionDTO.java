package com.example.demo.dto;

public class TerritoriesRegionDTO {

	private TerritoryDTO territoryDTO;
	public TerritoryDTO getTerritoryDTO() {

		return territoryDTO;

	}

	public void setTerritoryDTO(TerritoryDTO territoryDTO) {

		this.territoryDTO = territoryDTO;

	}

	public static class TerritoryDTO {

		private String territoryDescription;

		private int regionId;

		public String getTerritoryDescription() {

			return territoryDescription;

		}

		public void setTerritoryDescription(String territoryDescription) {

			this.territoryDescription = territoryDescription;

		}

		public int getRegionId() {

			return regionId;

		}

		public void setRegionId(int regionId) {

			this.regionId = regionId;

		}

	}

}