package com.example.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.OrderDetails;
import com.example.demo.exception.OrderDetailsNotFoundException;
import com.example.demo.repository.OrderDetailsRepository;

@Service
public class OrderDetailsServiceImpl implements OrderDetailsService {

	@Autowired
	OrderDetailsRepository OrderDetailsRepository;

	@Override
	public OrderDetails getOrderDetailsById(int OrderDetailsNumber) throws OrderDetailsNotFoundException {
		
		if (OrderDetailsRepository.findById(OrderDetailsNumber).isEmpty())
			
			throw new OrderDetailsNotFoundException("the OrderDetails with" + OrderDetailsNumber + "does not exists");
		
		return OrderDetailsRepository.findById(OrderDetailsNumber).get();
	}

	@Override
	public List<OrderDetails> getAllOrderDetails() {
		return OrderDetailsRepository.findAll();
	}

	@Override
	public void createOrderDetails(OrderDetails OrderDetails) {
		OrderDetailsRepository.save(OrderDetails);

	}

	@Override
	public OrderDetails updateOrderDetails(OrderDetails OrderDetails) throws OrderDetailsNotFoundException {
		int OrderDetailsId = OrderDetails.getOrderID();
		if (OrderDetailsRepository.findById(OrderDetailsId).isEmpty()) {
	        throw new OrderDetailsNotFoundException("The OrderDetails with ID " + OrderDetailsId + " does not exist");
	    }
	    return OrderDetailsRepository.save(OrderDetails);
	}

	@Override
	public void deleteOrderDetails(int OrderDetailsNumber) throws OrderDetailsNotFoundException {
		
		if (OrderDetailsRepository.findById(OrderDetailsNumber).isEmpty())
			
			throw new OrderDetailsNotFoundException("the OrderDetails with" + OrderDetailsNumber + "does not exists");
		OrderDetailsRepository.delete(OrderDetailsRepository.findById(OrderDetailsNumber).get());

	}

}

