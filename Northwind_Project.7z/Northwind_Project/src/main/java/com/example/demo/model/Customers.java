package com.example.demo.model;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "CUSTOMERS")
public class Customers {
	
	    @Id
	    @Column(name = "CUSTOMER_ID")
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private long customerId;

		@Column(name = "COMPANY_NAME")
		private String companyName;

		@Column(name = "CONTACT_NAME")
		private String contactName;

		@Column(name = "CONTACT_TITLE")
		private String contactTitle;

		@Column(name = "ADDRESS")
		private String address;

		@Column(name = "CITY")
		private String city;

		@Column(name = "REGION")
		private String region;

		@Column(name = "POSTAL_CODE")
		private String postalCode;

		@Column(name = "COUNTRY")
		private String country;

		@Column(name = "PHONE")
		private String phone;

		@Column(name = "FAX")
		private String fax;
		

		 @ManyToMany
		    @JoinTable(
		        name = "CUSTOMER_CUSTOMER_DEMO", // Name of the join table
		        joinColumns = @JoinColumn(name = "CUSTOMER_ID"), // Foreign key column in this entity
		        inverseJoinColumns = @JoinColumn(name = "CUSTOMER_TYPE_ID") // Foreign key column in the other entity
		    )
		 private Set<CustomerDemographics> customerDemographics = new HashSet<>();
		 
		 
		 @OneToMany(mappedBy = "customers", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
		 private List<Orders> orders;


		public long getCustomerId() {
			return customerId;
		}


		public void setCustomerId(long customerId) {
			this.customerId = customerId;
		}


		public String getCompanyName() {
			return companyName;
		}


		public void setCompanyName(String companyName) {
			this.companyName = companyName;
		}


		public String getContactName() {
			return contactName;
		}


		public void setContactName(String contactName) {
			this.contactName = contactName;
		}


		public String getContactTitle() {
			return contactTitle;
		}


		public void setContactTitle(String contactTitle) {
			this.contactTitle = contactTitle;
		}


		public String getAddress() {
			return address;
		}


		public void setAddress(String address) {
			this.address = address;
		}


		public String getCity() {
			return city;
		}


		public void setCity(String city) {
			this.city = city;
		}


		public String getRegion() {
			return region;
		}


		public void setRegion(String region) {
			this.region = region;
		}


		public String getPostalCode() {
			return postalCode;
		}


		public void setPostalCode(String postalCode) {
			this.postalCode = postalCode;
		}


		public String getCountry() {
			return country;
		}


		public void setCountry(String country) {
			this.country = country;
		}


		public String getPhone() {
			return phone;
		}


		public void setPhone(String phone) {
			this.phone = phone;
		}


		public String getFax() {
			return fax;
		}


		public void setFax(String fax) {
			this.fax = fax;
		}


		public Set<CustomerDemographics> getCustomerDemographics() {
			return customerDemographics;
		}


		public void setCustomerDemographics(Set<CustomerDemographics> customerDemographics) {
			this.customerDemographics = customerDemographics;
		}
		 
		 
		 
		

}
