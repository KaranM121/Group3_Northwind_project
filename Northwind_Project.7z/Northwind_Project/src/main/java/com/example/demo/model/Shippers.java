package com.example.demo.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name="SHIPPERS")
public class Shippers {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="SHIPPER_ID")
    private int shipperID;
	
	@Column(name="COMPANY_NAME")
	@Size(min=5, max=30, message="The company name must be between 5 and 30 characters")
	private String companyName;
	
	@Column(name="PHONE")
    private String phone;
	
	
	@OneToMany(mappedBy = "shippers", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Orders> orders;
 

    // Constructors (if needed)
    public Shippers() {
        // Default constructor
    }

 

    // Getter methods
    public int getShipperID() {
        return shipperID;
    }

 

    public String getCompanyName() {
        return companyName;
    }

 

    public String getPhone() {
        return phone;
    }

 

    // Setter methods
    public void setShipperID(int shipperID) {
        this.shipperID = shipperID;
    }

 

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

 

    public void setPhone(String phone) {
        this.phone = phone;
    }
}